package com.exemplo.vendasservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class VendasServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(VendasServiceApplication.class, args);
    }

}
